import { STATUS } from "./constants";
import { snackbarSuccess } from "@/utils/snackbar/snackbar.success";
import { snackbarError } from "@/utils/snackbar/snackbar.error";
import { $apiClient } from "@/utils/api/fetch.client";
import { $apiUserAxiosClient } from "@/utils/api/user/axios.user.client";
import { $apiAxiosClient } from "@/utils/api/axios.client";
import BlogVideoService from "@/services/blog/video/blogVideo.service";

const { upload } = new BlogVideoService($apiUserAxiosClient);

export function makeUploader({
    item,
    setUploads,
    abortControllersRef,
    // queryClient,
}) {
    return async () => {
        setUploads((prev) =>
            prev.map((u) =>
                u.id === item.id ? { ...u, status: STATUS.UPLOADING } : u,
            ),
        );

        try {
            let lastLoaded = 0;
            let lastTime = Date.now();
            const signal = abortControllersRef.current[item.id]?.signal;

            await upload(
                { video: item.file },
                {
                    headers: { "Content-Type": "multipart/form-data" },
                    signal,
                    onUploadProgress: (e) => {
                        const now = Date.now();
                        const dt = (now - lastTime) / 1000;
                        const speed = dt > 0 ? (e.loaded - lastLoaded) / dt : 0;
                        lastLoaded = e.loaded;
                        lastTime = now;
                        const progress = Math.round((e.loaded / e.total) * 100);
                        setUploads((prev) =>
                            prev.map((u) =>
                                u.id === item.id
                                    ? { ...u, progress, speed }
                                    : u,
                            ),
                        );
                    },
                },
            );
            // await $apiClient("/uploads/video", {
            //     signal,

            //     method: "POST",
            //     body: formData,
            //     // headers: { "Content-Type": "multipart/form-data" },
            //     onUploadProgress: (e) => {
            //         const now = Date.now();
            //         const dt = (now - lastTime) / 1000;
            //         const speed = dt > 0 ? (e.loaded - lastLoaded) / dt : 0;
            //         lastLoaded = e.loaded;
            //         lastTime = now;
            //         const progress = Math.round((e.loaded / e.total) * 100);
            //         setUploads((prev) =>
            //             prev.map((u) =>
            //                 u.id === item.id ? { ...u, progress, speed } : u,
            //             ),
            //         );
            //     },
            // });

            setUploads((prev) =>
                prev.map((u) =>
                    u.id === item.id
                        ? { ...u, status: STATUS.DONE, progress: 100, speed: 0 }
                        : u,
                ),
            );
            snackbarSuccess(`${item.file.name} загружено`);
            // queryClient.invalidateQueries({ queryKey: ["videos", 1] });
        } catch (err) {
            const isCancelled =
                err?.name === "CanceledError" ||
                err?.name === "AbortError" ||
                err?.code === "ERR_CANCELED" ||
                abortControllersRef.current[item.id]?.signal?.aborted;

            setUploads((prev) =>
                prev.map((u) =>
                    u.id === item.id
                        ? {
                              ...u,
                              status: isCancelled
                                  ? STATUS.CANCELLED
                                  : STATUS.ERROR,
                          }
                        : u,
                ),
            );

            if (!isCancelled) {
                snackbarError(`Ошибка: ${item.file.name}`);
            }
        } finally {
            delete abortControllersRef.current[item.id];
        }
    };
}
